import IntelligentArray

try:
	myarray = IntelligentArray()
	while(True):
		# Please take the time to play with those values.

		# This one could be the number of values you recorded.
		myarray.changeLength(int(input("Enter a length for your array: ")))
		# This one could be the data your sensor provides you.
		myarray.append(float(input("Enter a value: ")),
		# This one could be how much you trust this specific data.
			       float(input("... and a factor: ")))
		myarray.printMe()
except KeyboardInterrupt:
	pass
