class IntelligentArray:
	def __init__(self, length = 1):
		self.result = []
		self.length = length
		self.values = []
		self.factor = []
		for a in range(self.length):
			self.values.append(0)
			self.factor.append(0)
	def append(self, value, factor = 1):
		self.oldValues = []
		self.oldFactor = []
		for a in range(self.length):
			try:
				self.oldValues.append(self.values[a])
				self.oldFactor.append(self.factor[a])
			except IndexError:
				self.oldValues.append(0)
				self.oldFactor.append(0)
		self.values = []
		self.factor = []
		for a in range(self.length-1):
			self.values.append(self.oldValues[len(self.oldValues)-self.length+a+1])
			self.factor.append(self.oldFactor[len(self.oldFactor)-self.length+a+1])
			print(str(self.values[a]) + ", " + str(self.factor[a]))
		self.values.append(value)
		self.factor.append(factor)
		#self.oldValues = []
		#self.oldFactor = []
	def changeLength(self,length):
		self.oldValues = self.values
		self.oldFactor = self.factor
		self.values = []
		self.factor = []
		for a in range(length):
			if(length-a <= len(self.oldValues)):
				self.values.append(self.oldValues[len(self.oldValues)-length+a])
				self.factor.append(self.oldFactor[len(self.oldFactor)-length+a])
			else:
				self.values.append(0)
				self.factor.append(0)
		#self.oldValues = []
		#self.oldFactor = []
		self.length = length
	def printMe(self):
		print("Arrays: ")
		print(self.values)
		print(self.factor)
		print(self.getVal())
	def oldPrintMe(self):
		print("OldArrays: ")
		print(self.oldValues)
		print(self.oldFactor)
		#print(self.getVal())
	def getVal(self):
		try:
			self.result = []
			for a in range(self.length):
				if(self.factor[a] != 0):
					self.result.append(pow(self.values[a],self.factor[a]))
			print("Result: ")
			print(self.result)
			return(sum(self.result)/len(self.result))
		except ZeroDivisionError:
			print("ZeroDivisionError")
			return(0)
		except IndexError:
			print("IndexError")
			return(0)

if __name__ == "__main__":
	try:
		#myarray = IntelligentArray(int(input("Enter a length for your array: ")))
		myarray = IntelligentArray(4)
		while(True):
			myarray.changeLength(int(input("Enter a length for your array: ")))
			myarray.append(float(input("Enter a value: ")), float(input("... and a factor: ")))
			myarray.printMe()
	except KeyboardInterrupt:
		pass
