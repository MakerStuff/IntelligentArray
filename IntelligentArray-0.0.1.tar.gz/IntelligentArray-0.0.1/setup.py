import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="IntelligentArray",
    version="0.0.1",
    author="Fabian Becker",
    author_email="fab.becker@outlook.de",
    description="Create an array of values (eg. sensordata) and how much they are worth and get the average.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/MakerStuff/IntelligentArray",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Framework :: IDLE",
    ],
)
